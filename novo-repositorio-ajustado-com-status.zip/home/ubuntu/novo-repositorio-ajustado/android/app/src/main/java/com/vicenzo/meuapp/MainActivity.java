package com.vicenzo.meuapp;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
